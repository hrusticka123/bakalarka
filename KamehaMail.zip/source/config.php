<?php

//config file, defining several global variables

define("maildir", '/path/to/mailboxes');
define("datadir", '/path/to/databases');
define("source", '/path/to/source/files');
define("domain", 'domain');


?>